import express from 'express'

const servidor = express()
servidor.use(express.json())

const filmes = []
const jogos = [] 

servidor.get('/filmes', (req, res) => {
 res.send(filmes)
})

servidor.post('/filmes', (req, res) => {
    const filme = req.body
    filmes.push(filme)

    res.send('Filme cadastrado')
})

servidor.get('/jogos', (req, res) => {
 res.send(jogos)
})

servidor.post('/jogos', (req, res) => {
    const jogo = req.body
    jogos.push(jogo)

    res.send('jogo cadastrado')
})

servidor.listen(1234)